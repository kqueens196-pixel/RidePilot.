# Android App

This folder is the planned Android module.

Recommended screens:
1. Splash
2. Mobile + OTP login
3. Profile
4. Vehicle selection
5. Permission center
6. Home/dashboard
7. Order mode selector
8. Distance/radius filters
9. Connected platforms
10. Subscription
11. Order history
12. Settings/support

Auto-accept UI must clearly state that it works only for authorized provider integrations.
